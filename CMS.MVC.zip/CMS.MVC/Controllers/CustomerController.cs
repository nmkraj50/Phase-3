﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CMS.MVC.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult AddCustomer()
        {
            return View();
        }
        public ActionResult DeleteByID()
        {
            return View();
        }
        public ActionResult DeleteByName()
        {
            return View();
        }
        public ActionResult DeleteMenu()
        {
            return View();
        }
        public ActionResult SearchByID()
        {
            return View();
        }
        public ActionResult SearchByName()
        {
            return View();
        }
        public ActionResult SearchMenu()
        {
            return View();
        }
        public ActionResult UpdateByID()
        {
            return View();
        }
        public ActionResult UpdateByName()
        {
            return View();
        }
        public ActionResult UpdateMenu()
        {
            return View();
        }
        public ActionResult ViewCustomers()
        {
            return View();
        }
    }
}