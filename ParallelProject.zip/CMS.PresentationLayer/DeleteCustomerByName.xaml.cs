﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.Entities;
using CMS.BusinessLogicLayer;
using CMS.Exceptions;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for DeleteCustomerByName.xaml
    /// </summary>
    public partial class DeleteCustomerByName : Window
    {
        public DeleteCustomerByName()
        {
            InitializeComponent();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            Customer list = (Customer)dgCustomers.SelectedItem;
            if(list!=null)
            {
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Do you want to delete this customer?", "Delete confirmation", System.Windows.MessageBoxButton.YesNo);
                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    int deleteCustomerID = list.CustomerID;
                    bool customerDeleted = CustomerBLL.RemoveCustomerBLL(deleteCustomerID);
                    if (customerDeleted)
                    {
                        MessageBox.Show("Customer Deleted");
                        string searchCustomerName = txtName.Text;
                        List<Customer> customerList = CustomerBLL.SearchCustomerByNameBLL(searchCustomerName);
                        if (customerList.Count == 0)
                        {
                            dgCustomers.HeadersVisibility = DataGridHeadersVisibility.None;
                        }
                        dgCustomers.ItemsSource = customerList;
                    }
                    else
                        MessageBox.Show("Customer Not Deleted!");
                }
                else
                    MessageBox.Show("Customer Not Found!");
            }
        }

        private void BtnShow_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string searchCustomerName = txtName.Text;

                List<Customer> searchCustomers = CustomerBLL.SearchCustomerByNameBLL(searchCustomerName);

                if (searchCustomers != null)
                {
                    dgCustomers.ItemsSource = searchCustomers.ToList();

                }
                else
                {
                    MessageBox.Show("No Customer Details Available");
                }


            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
