﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for DeleteCustomerMenu.xaml
    /// </summary>
    public partial class DeleteCustomerMenu : Window
    {
        public DeleteCustomerMenu()
        {
            InitializeComponent();
            
        }

        private void BtnDeleteByID_Click(object sender, RoutedEventArgs e)
        {
            DeleteCustomerByID win1 = new DeleteCustomerByID();
            win1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win1.Show();
            //DisableAllButtons();
        }

        private void BtnDeleteByName_Click(object sender, RoutedEventArgs e)
        {
            DeleteCustomerByName win2 = new DeleteCustomerByName();
            win2.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            win2.Show();
            //DisableAllButtons();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
