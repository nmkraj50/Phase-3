﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CMS.Exceptions;
using CMS.Entities;
using CMS.BusinessLogicLayer;

namespace CMS.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ModifyCustomer.xaml
    /// </summary>
    public partial class ModifyCustomer : Window
    {
        public ModifyCustomer()
        {
            InitializeComponent();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int searchCustomerID;

                searchCustomerID = Convert.ToInt32(txtID.Text);
                Customer searchCustomer = CustomerBLL.SearchCustomerByIdBLL(searchCustomerID);
                if (searchCustomer != null)
                {
                    txtName.Text = searchCustomer.CustomerName;
                    txtCity.Text = searchCustomer.City;
                    txtAge.Text = searchCustomer.Age.ToString();
                    txtPhone.Text = searchCustomer.Phone.ToString();
                    txtPincode.Text = searchCustomer.Pincode.ToString();

                }
                else
                {
                    MessageBox.Show("Customer Details Not Available");
                }

            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Customer customer = new Customer();
                customer.CustomerID = Convert.ToInt32(txtID.Text);
                customer.CustomerName = txtName.Text;
                customer.City = txtCity.Text;
                customer.Age = Convert.ToInt32(txtAge.Text);
                customer.Phone = Convert.ToInt64(txtPhone.Text);
                customer.Pincode = Convert.ToInt32(txtPincode.Text);
                bool employeeUpdated = CustomerBLL.ModifyCustomerBLL(customer);
                if (employeeUpdated)
                    MessageBox.Show("Customer Details Updated!");
                else
                    MessageBox.Show("Customer Details can't be Updated!");
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
            this.Close();
        }
    }
}
